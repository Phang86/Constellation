package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import bean.My;
import bean.News;
import bean.User;
import bean.VideoList;
import util.DBConnection;

public class UserDAO {
	//tb_user����¼
	public List<User> findAll(String user, String pwd){
		List<User> list = new ArrayList<>();
		Connection connection = DBConnection.getCon();
		String sql = "select * from tb_user where username=? and password=?";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, user);
			pst.setString(2, pwd);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				User u = new User();
				u.setUserId(rst.getInt("user_id"));
				u.setUserName(rst.getString("username"));
				u.setMobile(rst.getString("mobile"));
				u.setPassWord(rst.getString("password"));
				u.setCreateTime(rst.getString("create_time"));
				u.setUpdateTime(rst.getString("update_time"));
				list.add(u);
			}
			DBConnection.close(connection, pst, rst);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	
	//select * from tb_user where username=?
	public List<User> findByName(String user){
		List<User> list = new ArrayList<>();
		Connection connection = DBConnection.getCon();
		String sql = "select * from tb_user where username=?";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, user);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				User u = new User();
				u.setUserId(rst.getInt("user_id"));
				u.setUserName(rst.getString("username"));
				u.setMobile(rst.getString("mobile"));
				u.setPassWord(rst.getString("password"));
				u.setCreateTime(rst.getString("update_time"));
				list.add(u);
			}
			DBConnection.close(connection, pst, rst);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
			
	
	//tb_user�����û����͵绰�һ�����
	public List<User> findByPwd(String user, String phone){
		List<User> list = new ArrayList<>();
		Connection connection = DBConnection.getCon();
		String sql = "select * from tb_user where username=? and mobile=?";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, user);
			pst.setString(2, phone);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				User u = new User();
				u.setUserId(rst.getInt("user_id"));
				u.setUserName(rst.getString("username"));
				u.setMobile(rst.getString("mobile"));
				u.setPassWord(rst.getString("password"));
				u.setCreateTime(rst.getString("update_time"));
				list.add(u);
			}
			DBConnection.close(connection, pst, rst);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	
	//tb_user��ע��
	public int add(String name,String phone,String passWord,String createTime,String updateTime) {
		int num = 0;
		Connection con = DBConnection.getCon();
		String sql = "insert into tb_user values(null,?,?,?,?,?)";
		try {
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, name);
			pst.setString(2, phone);
			pst.setString(3, passWord);
			pst.setString(4, createTime);
			pst.setString(5, updateTime);
			num = pst.executeUpdate();
			DBConnection.close(con, pst, null);
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return num;
	}
	
	//tb_user���޸�
	public int update(User user) {
		int num = 0;
		Connection con = DBConnection.getCon();
		String sql = "update tb_user set password=?,update_time=? where username=?";
		try {
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, user.getPassWord());
			pst.setString(2, user.getUpdateTime());
			pst.setString(3, user.getUserName());
			num = pst.executeUpdate();
			DBConnection.close(con, pst, null);
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return num;
	}
	
	//tb_user��ɾ��
	public int delete(User user) {
		int num = 0;
		Connection con = DBConnection.getCon();
		String sql = "delete from tb_user where username=?";
		try {
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, user.getUserName());
			num = pst.executeUpdate();
			DBConnection.close(con, pst, null);
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return num;
	}
	
	//tb_user���绰�޸�
	public int updatePhone(String phone,String updateTime,String user) {
		int num = 0;
		Connection con = DBConnection.getCon();
		String sql = "update tb_user set mobile=?,update_time=? where username=?";
		try {
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, phone);
			pst.setString(2, updateTime);
			pst.setString(3, user);
			num = pst.executeUpdate();
			DBConnection.close(con, pst, null);
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return num;
	}
	
	//video_list��
	public List<VideoList> findVideoAll() {
		List<VideoList> list = new ArrayList<>();
		Connection connection = DBConnection.getCon();
		String sql = "select * from video_list";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				VideoList vl = new VideoList();
				vl.setvId(rst.getInt("vid"));
				vl.setTitle(rst.getString("vtitle"));
				vl.setAuthor(rst.getString("author"));
				vl.setCoverUrl(rst.getString("coverUrl"));
				vl.setHeadurl(rst.getString("headurl"));
				vl.setCommentNum(rst.getInt("comment_num"));
				vl.setLikeNum(rst.getInt("like_num"));
				vl.setCollectNum(rst.getInt("collect_num"));
				vl.setPlayUrl(rst.getString("playUrl"));
				vl.setCreateTime(rst.getString("create_time"));
				list.add(vl);
			}
			DBConnection.close(connection, pst, rst);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	
	//legion_list��
	public List<VideoList> findLegionAll() {
		List<VideoList> list = new ArrayList<>();
		Connection connection = DBConnection.getCon();
		String sql = "select * from legion_list";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				VideoList vl = new VideoList();
				vl.setvId(rst.getInt("vid"));
				vl.setTitle(rst.getString("vtitle"));
				vl.setAuthor(rst.getString("author"));
				vl.setCoverUrl(rst.getString("coverUrl"));
				vl.setHeadurl(rst.getString("headurl"));
				vl.setCommentNum(rst.getInt("comment_num"));
				vl.setLikeNum(rst.getInt("like_num"));
				vl.setCollectNum(rst.getInt("collect_num"));
				vl.setPlayUrl(rst.getString("playUrl"));
				vl.setCreateTime(rst.getString("create_time"));
				list.add(vl);
			}
			DBConnection.close(connection, pst, rst);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	
	//hot_list��
	public List<VideoList> findHotAll() {
		List<VideoList> list = new ArrayList<>();
		Connection connection = DBConnection.getCon();
		String sql = "select * from hot_list";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				VideoList vl = new VideoList();
				vl.setvId(rst.getInt("vid"));
				vl.setTitle(rst.getString("vtitle"));
				vl.setAuthor(rst.getString("author"));
				vl.setCoverUrl(rst.getString("coverUrl"));
				vl.setHeadurl(rst.getString("headurl"));
				vl.setCommentNum(rst.getInt("comment_num"));
				vl.setLikeNum(rst.getInt("like_num"));
				vl.setCollectNum(rst.getInt("collect_num"));
				vl.setPlayUrl(rst.getString("playUrl"));
				vl.setCreateTime(rst.getString("create_time"));
				list.add(vl);
			}
			DBConnection.close(connection, pst, rst);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	
	//movie_list��
	public List<VideoList> findMovieAll() {
		List<VideoList> list = new ArrayList<>();
		Connection connection = DBConnection.getCon();
		String sql = "select * from movie_list";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				VideoList vl = new VideoList();
				vl.setvId(rst.getInt("vid"));
				vl.setTitle(rst.getString("vtitle"));
				vl.setAuthor(rst.getString("author"));
				vl.setCoverUrl(rst.getString("coverUrl"));
				vl.setHeadurl(rst.getString("headurl"));
				vl.setCommentNum(rst.getInt("comment_num"));
				vl.setLikeNum(rst.getInt("like_num"));
				vl.setCollectNum(rst.getInt("collect_num"));
				vl.setPlayUrl(rst.getString("playUrl"));
				vl.setCreateTime(rst.getString("create_time"));
				list.add(vl);
			}
			DBConnection.close(connection, pst, rst);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	
	//politics_list��
	public List<VideoList> findPoliticsAll() {
		List<VideoList> list = new ArrayList<>();
		Connection connection = DBConnection.getCon();
		String sql = "select * from politics_list";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				VideoList vl = new VideoList();
				vl.setvId(rst.getInt("vid"));
				vl.setTitle(rst.getString("vtitle"));
				vl.setAuthor(rst.getString("author"));
				vl.setCoverUrl(rst.getString("coverUrl"));
				vl.setHeadurl(rst.getString("headurl"));
				vl.setCommentNum(rst.getInt("comment_num"));
				vl.setLikeNum(rst.getInt("like_num"));
				vl.setCollectNum(rst.getInt("collect_num"));
				vl.setPlayUrl(rst.getString("playUrl"));
				vl.setCreateTime(rst.getString("create_time"));
				list.add(vl);
			}
			DBConnection.close(connection, pst, rst);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	
	public List<News> findNews() {
		List<News> list = new ArrayList<>();
		Connection connection = DBConnection.getCon();
		String sql = "select * from news";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				News ne = new News();
				ne.setNewsTitle(rst.getString("news_title"));
				ne.setAuthorName(rst.getString("author_name"));
				ne.setHeaderUrl(rst.getString("header_url"));
				ne.setCommentCount(rst.getInt("comment_count"));
				ne.setReleaseDate(rst.getString("release_date"));
				ne.setPicx(rst.getString("picx"));
				ne.setPicxx(rst.getString("picxx"));
				ne.setPicxxx(rst.getString("picxxx"));
				ne.setType(rst.getInt("type"));
				list.add(ne);
			}
			DBConnection.close(connection, pst, rst);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	
	public List<My> findMy() {
		List<My> list = new ArrayList<>();
		Connection connection = DBConnection.getCon();
		String sql = "select * from my";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				My me = new My();
				me.setTitleImg(rst.getString("title_img"));
				me.setTitleName(rst.getString("title_name"));
				me.setTitleAuthor(rst.getString("title_author"));
				me.setReadCount(rst.getInt("read_count"));
				me.setLikeCount(rst.getInt("like_count"));
				me.setCommentCount(rst.getInt("comment_count"));
				me.setEnjoyCount(rst.getInt("enjoy_count"));
				list.add(me);
			}
			DBConnection.close(connection, pst, rst);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}

}
