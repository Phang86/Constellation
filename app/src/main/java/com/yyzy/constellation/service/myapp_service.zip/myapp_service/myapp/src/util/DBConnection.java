package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DBConnection {
	private static final  String DRIVERNAME = "com.mysql.cj.jdbc.Driver";
	private static final  String URL = "jdbc:mysql://localhost:3306/myapp?characterEncoding=UTF-8";
	private static final  String USER = "root";
	private static final  String PWD = "123456";
	
	
//	static{
//		try{
//			Class.forName(DRIVERNAME);
//		}catch (Exception e){
//			e.printStackTrace();
//		}
//	}
//	
//	private static Connection conn = null;
//	//����ģʽ�������ݿ�����
//	public static Connection getConnection(){
//		try {
//			if(conn == null){
//				conn = DriverManager.getConnection(URL, USER, PWD);
//				return conn;
//			}else{
//				return conn;
//			}
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//		return conn;
//	}
	
	
	
	
	public static final Connection getCon() {
		Connection connection = null;
		try {
			Class.forName(DRIVERNAME);
			connection = DriverManager.getConnection(URL,USER,PWD);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return connection;
	}
	
	
	
	
	public static void close(Connection con, PreparedStatement pst, ResultSet rst) {
		try {
			if (con != null) {
				con.close();
			}
			if (pst != null) {
				pst.close();
			}
			if (rst != null) {
				rst.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) throws Exception {
		System.out.println(DBConnection.getCon());
	}
}
