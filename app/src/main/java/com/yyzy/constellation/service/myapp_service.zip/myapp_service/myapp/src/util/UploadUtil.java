package util;

import java.util.UUID;

public class UploadUtil {
	//��ȡ���ͼƬ����
	public static String getUUIDName(String realName) {
		int index = realName.lastIndexOf(".");
		if (index == -1) {
			return UUID.randomUUID().toString().replace("-","").toUpperCase();
		}else {
			return UUID.randomUUID().toString().replace("-","").toUpperCase()+realName.substring(index);
		}
	}
	
	//��ȡ��ʵͼƬ����
	public static String getrealName(String name) {
		int index = name.lastIndexOf("\\");
		return name.substring(index+1);
	}
	
	//��ȡ�ļ�Ŀ¼
	public static String getDir(String name) {
		int i = name.hashCode();
		String hex = Integer.toHexString(i);
		int j = hex.length();
		for(int k = 0; k < 8-j; k++) {
			hex = "0"+hex;
		}
		return "/"+hex.charAt(0)+"/"+hex.charAt(1);
	}
	
	public static void main(String[] args) {
		String str = "C:\\Users\\Administrator\\Pictures\\Saved Pictures\\imgheader.jpg";
		
		String uuid = getUUIDName(str);
		System.out.println("������ɵ�ͼƬ���ƣ�"+uuid);
		
		String realName = getrealName(str);
		System.out.println("��ʵ��ͼƬ���ƣ�"+realName);
		
		String dir = getDir(str);
		System.out.println("ͼƬ·����"+dir);
	}
}
