package servlet;

import java.awt.List;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import dao.UserDAO;
import util.EncryptionUtil;

/**
 * Servlet implementation class UpdatePhoneServlet
 */
@WebServlet("/update/phone")
public class UpdatePhoneServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdatePhoneServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		String username = request.getParameter("user");
		String phone = request.getParameter("phone");
		Date date = new Date(System.currentTimeMillis());
		SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
		String updateTime = time.format(date);
//		User user = new User(phone,username);
		int update = new UserDAO().updatePhone(phone,updateTime,username);
		java.util.List<User> list = new ArrayList<>();
		list = new UserDAO().findByPhone(phone);
		PrintWriter out = response.getWriter();
		if (update > 0) {
			out.print("success");
			out.flush();
			out.close();
		}else {
			if (list.size() > 0 && list != null) {
				out.print("su_error");
				out.flush();
				out.close();
				return;
			}
			out.print("error");
			out.flush();
			out.close();
		}
	}

}
