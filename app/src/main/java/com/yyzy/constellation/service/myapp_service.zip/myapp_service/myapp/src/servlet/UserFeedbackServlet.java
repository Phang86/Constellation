package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDAO;
import util.EncryptionUtil;

/**
 * Servlet implementation class UserFeedbackServlet
 */
@WebServlet("/user/feedback")
public class UserFeedbackServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserFeedbackServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		String name = request.getParameter("user");
		String phone = request.getParameter("mobile");
		String repPhone = phone.replace(" ", "");
		String ipaddress = request.getParameter("ipAddress");
		String content = request.getParameter("feedBackContent");
//		SimpleDateFormat time = new SimpleDateFormat("yyyy��MM��dd�� HHʱmm��ss E");
//        String createTime = time.format(new Date(System.currentTimeMillis()));
		String createTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		UserDAO dao = new UserDAO();
		int add = dao.addFeed(name, repPhone, ipaddress, content,1, createTime);
		PrintWriter out = response.getWriter();
		if (add > 0) {
			out.print("success");
			out.flush();
			out.close();
			return;
		}
		out.print("error");
		out.flush();
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
