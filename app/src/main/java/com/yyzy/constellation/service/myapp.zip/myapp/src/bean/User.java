package bean;


public class User {
	private Integer userId;
	private String userName;
	private String mobile;
	private String passWord;
	private String createTime;
	private String updateTime;
	
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
		
	}
	
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
		
	}
	
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	
	public User() {
		super();
	}
	
	public User(String userName, String mobile, String passWord, String createTime, String updateTime) {
		super();
		this.userName = userName;
		this.mobile = mobile;
		this.passWord = passWord;
		this.createTime = createTime;
		this.updateTime = updateTime;
	}
	
	public User(String mobile, String userName) {
		super();
		this.mobile = mobile;
		this.userName = userName;
	}
	
	public User(String userName, String passWord, String updateTime) {
		super();
		this.userName = userName;
		this.passWord = passWord;
		this.updateTime = updateTime;
	}
	
	public User(String userName) {
		super();
		this.userName = userName;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", mobile=" + mobile + ", passWord=" + passWord
				+ ", createTime=" + createTime + ", updateTime=" + updateTime + "]";
	}
	
	
}
