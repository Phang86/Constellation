package bean;

public class VideoList{
	
	private int vId;
	private String title;
	private String author;
	private String coverUrl;
	private String headurl;
	private int commentNum;
	private int likeNum;
	private int collectNum;
	private String playUrl;
	private String createTime;
	public String getCreateTime() {
		return createTime;
	}
	
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public int getvId() {
		return vId;
	}
	public void setvId(int vId) {
		this.vId = vId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getCoverUrl() {
		return coverUrl;
	}
	public void setCoverUrl(String coverUrl) {
		this.coverUrl = coverUrl;
	}
	public String getHeadurl() {
		return headurl;
	}
	public void setHeadurl(String headurl) {
		this.headurl = headurl;
	}
	public int getCommentNum() {
		return commentNum;
	}
	public void setCommentNum(int commentNum) {
		this.commentNum = commentNum;
	}
	public int getLikeNum() {
		return likeNum;
	}
	public void setLikeNum(int likeNum) {
		this.likeNum = likeNum;
	}
	public int getCollectNum() {
		return collectNum;
	}
	public void setCollectNum(int collectNum) {
		this.collectNum = collectNum;
	}
	
	
	
	public String getPlayUrl() {
		return playUrl;
	}
	public void setPlayUrl(String playUrl) {
		this.playUrl = playUrl;
	}
	@Override
	public String toString() {
		return "VideoList [vId=" + vId + ", title=" + title + ", author=" + author + ", coverUrl=" + coverUrl
				+ ", headurl=" + headurl + ", commentNum=" + commentNum + ", likeNum=" + likeNum + ", collectNum="
				+ collectNum + ", playUrl=" + playUrl + "]";
	}
	
	
}
