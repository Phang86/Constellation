package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.xdevapi.JsonArray;
import com.sun.org.apache.bcel.internal.generic.NEW;

import bean.User;
import dao.UserDAO;
import net.sf.json.JSON;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.util.CycleDetectionStrategy;
import util.EncryptionUtil;

/**
 * Servlet implementation class UserFindServlet
 */
@WebServlet("/user/login")
public class UserFindServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserFindServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setContentType("application/json;charset=UTF-8");
		List<User> list = new ArrayList<User>();
		String user = request.getParameter("user");
		//����
		String pwd = request.getParameter("pwd");
		//����
		String enpwd = EncryptionUtil.getHash2(pwd, "MD5");
		list = new UserDAO().findAll(user, enpwd);
		PrintWriter out = response.getWriter();
		if (list.size() > 0 && list != null) {
			JSONArray json = JSONArray.fromObject(list);
			out.print(json);
			out.flush();
			out.close();
		}else{
			out.print("error");
			out.flush();
			out.close();
		}
		//request.getRequestDispatcher("UserFile.jsp").forward(request, response);
	}

}
