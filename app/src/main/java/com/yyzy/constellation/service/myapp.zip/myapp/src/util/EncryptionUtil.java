package util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.sun.org.apache.bcel.internal.generic.NEW;

import bean.User;
import dao.UserDAO;

public class EncryptionUtil {
	/** @param source ��Ҫ���ܵ��ַ���
	   * @param hashType  �������� ��MD5 �� SHA��
	   * @return
	   */
	  public static String getHash2(String source, String hashType) {
	    StringBuilder sb = new StringBuilder();
	    MessageDigest md5;
	    try {
	      md5 = MessageDigest.getInstance(hashType);
	      md5.update(source.getBytes());
	      for (byte b : md5.digest()) {
	        sb.append(String.format("%02X", b)); // 10����ת16���ƣ�X ��ʾ��ʮ��������ʽ�����02 ��ʾ������λǰ�油0���
	      }
	      return sb.toString();
	    } catch (NoSuchAlgorithmException e) {
	      e.printStackTrace();
	    }
	    return null;
	  }
	  //final static String pwd = "penghang";
	  
	  public static void main(String[] args) {
//		  SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
//		  String updateTime = sdf.format(new Date());
//		  UserDAO dao = new UserDAO();
//		  int add = dao.add("penghang", "151 758964988", "jfdsifojdf", updateTime, updateTime);
//		  User user = new User();
//		  user.setUserName("fjsdifids");
//		  int del = dao.delete(user);
//		  if (del > 0) {
//			  System.out.println("ɾ���ɹ�");
//		  }else {
//			  System.out.println("ɾ��ʧ��");
//		  }
	}
}
