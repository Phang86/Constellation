package servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.tomcat.util.http.fileupload.IOUtils;

import dao.UserDAO;
import net.sf.json.JSONArray;
import util.UploadUtil;

/**
 * Servlet implementation class UpdateUserImg
 */
@WebServlet("/update/user/img")
public class UpdateUserImg extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String username;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateUserImg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
//		response.setContentType("text/html;charset=UTF-8");
//		response.setCharacterEncoding("UTF-8");
//		String username = request.getHeader("user");
//		PrintWriter out = response.getWriter();
//		if (username == null) {
//			out.print("error");
//			out.flush();
//			out.close();
//			return;
//		}
//		this.username = username;
//		System.out.println("�û�����"+username);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		String username = request.getHeader("user");
		PrintWriter out = response.getWriter();
		if (username == null) {
			out.print("error");
			out.flush();
			out.close();
			return;
		}
		//����ͷ��
		try {
			HashMap<String, Object> map = new HashMap<String, Object>();
			//����������ļ���
			DiskFileItemFactory factory = new DiskFileItemFactory();
			//���������ϴ�����
			ServletFileUpload upload = new ServletFileUpload(factory);
			//����request��ֵ��
			List<FileItem> list = upload.parseRequest(request);
			for (FileItem fi : list) {
				//�ж��Ƿ���ͨ�ϴ����
				if (fi.isFormField()) {
					map.put(fi.getFieldName(),fi.getString("utf-8"));
				}else {
					//�ļ��ϴ����
					//��ȡ�ļ�����
					String name = fi.getName();
					String realName = UploadUtil.getrealName(name);
					String uuidName = UploadUtil.getUUIDName(name);
					
					String path = getServletContext().getRealPath("/imgHeader/0");
					System.out.println("��ʵͼƬ���ƣ�"+realName+"\n���ͼƬ���ƣ�"+uuidName+"\n��ŵ�ַ��"+path);
					
					//��ȡ�ϴ����ļ���
					InputStream is = fi.getInputStream();
					FileOutputStream os = new FileOutputStream(new File(path,uuidName));
					IOUtils.copy(is,os);
					os.close();
					is.close();
					fi.delete();
					map.put(fi.getFieldName(), "/imgHeader/0/"+uuidName);
					String img = String.valueOf(map.get(fi.getFieldName()));
					int up = new UserDAO().updateImg(img,username);
					System.out.println("ͼƬ·��Ϊ��http://192.168.2.20:8080/myapp"+map.get(""+fi.getFieldName()));
					if (up > 0) {
						out.print("s_success");
						out.flush();
						out.close();
						return;
					}
					out.print("s_error");
					out.flush();
					out.close();
				}
			}
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
