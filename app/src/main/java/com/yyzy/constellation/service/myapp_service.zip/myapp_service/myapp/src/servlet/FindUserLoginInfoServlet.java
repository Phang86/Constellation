package servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.tomcat.util.http.fileupload.IOUtils;

import bean.FeedBackBean;
import bean.LoginInfoBean;
import dao.UserDAO;
import net.sf.json.JSONArray;
import sun.nio.ch.IOUtil;
import util.UploadUtil;

/**
 * Servlet implementation class FindUserLoginInfoServlet
 */
@WebServlet("/find/user/login/info")
public class FindUserLoginInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FindUserLoginInfoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("application/json;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		// TODO Auto-generated method stub
		String user = request.getParameter("user");
		
		List<LoginInfoBean> list = new ArrayList<LoginInfoBean>();
		list = new UserDAO().findByLoginInfo(user);
		PrintWriter out = response.getWriter();
		JSONArray array = JSONArray.fromObject(list);
		if (list.size() > 0 && list != null) {
			out.print(array.toString());
			System.out.println(array.toString());
			out.flush();
			out.close();
			return;
		}
		out.print("error");
		out.flush();
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
